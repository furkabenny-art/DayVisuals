package dayvisuals;

import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.RenderTickCounter;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(WorldRenderer.class)
public class WorldRendererMixin {
    @Inject(method = "render", at = @At("TAIL"))
    private void onRenderWorldTail(RenderTickCounter tickCounter, boolean renderBlockOutline, 
                                   net.minecraft.client.render.Camera camera, 
                                   net.minecraft.client.render.GameRenderer gameRenderer, 
                                   Matrix4f lightmapTextureMatrix, Matrix4f projectionMatrix, 
                                   CallbackInfo ci) {
        MatrixStack matrices = new MatrixStack(); 
        DayVisuals.render3D(matrices, tickCounter.getTickDelta(false));
    }
}